$(document).ready(function () {

    $('#PrintPage').click(function(){
        window.print();
        return false;
    });
    
})